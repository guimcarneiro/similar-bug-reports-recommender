from utils import calculate_cos_similarity, calculate_categoric_fields_similarity, deconvert_from_binary
class SimilarBugReportsRecommendationSystem():
    def __init__(self, data_loader):
        self.data             = data_loader
        self.categoric_fields = ["product", "component"]
    
    def _calculate_score(self, tfidf_score, embeddings_score, categoric_score):
        # TODO: enhance calculation
        TFIDF_WEIGHT    = 0.5
        BERT_WEIGHT     = 0.5
        CATEGORIC_SCORE = 0.5

        return ((TFIDF_WEIGHT*tfidf_score) + (BERT_WEIGHT*embeddings_score) + (CATEGORIC_SCORE*categoric_score))/(TFIDF_WEIGHT + BERT_WEIGHT + CATEGORIC_SCORE)

    def _format_result(self, item, score):
        #{
        #    "bg_number"       : str(db_bug_report["bg_number"]),
        #    "summary"         : db_bug_report["summary"],
        #    "description"     : db_bug_report["description"],
        #    "product"         : db_bug_report["product"],
        #    "component"       : db_bug_report["component"],
        #    "platform"        : db_bug_report["platform"],
        #    "type"            : db_bug_report["type"],
        #    "tfidf_vector"    : db_bug_report["tfidf_vector"],
        #    "bert_embeddings" : db_bug_report["embeddings_vector"],
        #    "creation_time"   : db_bug_report["creation_time"],
        #    "assigned_to"     : db_bug_report["assigned_to"]
        #}
        
        return {
            "recommendation": item,
            "score": score
        }

    def get_recommendations(self, query, K=10, convert_binary=False, eval_mode=False):
        if eval_mode:
            corpus = self.data.retrieve_open_reports()
        else:
            corpus = self.data.retrieve_open_reports(extra_filters={
            "when_changed_to_resolved": {
                "$gt": query["creation_time"]
            }
        })
        
        ranking = []
        for doc in corpus:
            if doc["bg_number"] == query["bg_number"]:
                continue

            categoric_score  = calculate_categoric_fields_similarity(query, doc, self.categoric_fields)

            # jump off if categoric score is 0, save processing time
            if categoric_score == 0:
                continue

            if convert_binary:
                query_tfidf_vector    = deconvert_from_binary(query["tfidf_vector"])
                query_bert_embeddings = deconvert_from_binary(query["embeddings_vector"])
            else:
                query_tfidf_vector    = query["tfidf_vector"]
                query_bert_embeddings = query["embeddings_vector"]

            tfidf_score      = calculate_cos_similarity(query_tfidf_vector, doc["tfidf_vector"])
            embeddings_score = calculate_cos_similarity([query_bert_embeddings], [doc["bert_embeddings"]])

            general_score    = self._calculate_score(tfidf_score=tfidf_score, embeddings_score=embeddings_score, categoric_score=categoric_score)

            recommendation_obj = {
                "doc": doc,
                "score": general_score
            }

            ranking.append(recommendation_obj)

        ranking.sort(key=lambda r: r["score"], reverse=True)

        ranking = [ self._format_result(r["doc"], r["score"]) for r in ranking[:K] ]

        return ranking