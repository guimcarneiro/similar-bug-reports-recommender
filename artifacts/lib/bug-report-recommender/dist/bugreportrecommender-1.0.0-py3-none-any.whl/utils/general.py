import pickle

def deconvert_from_binary(bin):
    return pickle.loads(bin)
